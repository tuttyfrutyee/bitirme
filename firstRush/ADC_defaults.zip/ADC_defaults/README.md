## SPI master example

This code displays some simple graphics with varying pixel colors on the 320x240 LCD on an ESP-WROVER-KIT board.

If you want to adapt this example to another type of display or pinout, check [main/spi_master_example_main.c] for comments with some implementation details.
